# on-prem-or-cloud-agnostic-kubernetes
Setting up and running an on-prem or cloud agnostic Kubernetes cluster

This is the course material for the On-Prem or Cloud Agnostic Udemy Course on Udemy (see https://www.udemy.com/learn-devops-on-prem-or-cloud-agnostic-kubernetes/?couponCode=KUBERNETES_GIT)
